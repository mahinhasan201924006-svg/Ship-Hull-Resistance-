"""
Main training script with model comparison and visualization.
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_score, KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import xgboost as xgb
import joblib
from pathlib import Path

from utils import (load_dataset, detect_task_type, preprocess_data, 
                   save_figure, setup_directories, RANDOM_STATE)
from preprocess import (generate_data_stats, generate_feature_distributions,
                       generate_correlation_heatmap)


def train_models(X_train, y_train):
    """Train multiple regression models."""
    models = {
        'Linear Regression': LinearRegression(),
        'Random Forest': RandomForestRegressor(n_estimators=100, random_state=RANDOM_STATE, n_jobs=-1),
        'XGBoost': xgb.XGBRegressor(n_estimators=100, random_state=RANDOM_STATE, n_jobs=-1)
    }

    print("\n🔄 Training models...")
    trained_models = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        trained_models[name] = model
        print(f"  ✓ {name} trained")

    return trained_models


def evaluate_models(models, X_train, y_train, X_test, y_test, cv_folds=5):
    """Perform cross-validation and test set evaluation."""
    kfold = KFold(n_splits=cv_folds, shuffle=True, random_state=RANDOM_STATE)

    results = {}
    print("\n📊 Evaluating models...")

    for name, model in models.items():
        # Cross-validation
        cv_scores = cross_val_score(model, X_train, y_train, cv=kfold, 
                                   scoring='neg_mean_squared_error', n_jobs=-1)
        cv_rmse = np.sqrt(-cv_scores)

        # Test set predictions
        y_pred = model.predict(X_test)

        results[name] = {
            'cv_rmse_mean': cv_rmse.mean(),
            'cv_rmse_std': cv_rmse.std(),
            'test_rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'test_mae': mean_absolute_error(y_test, y_pred),
            'test_r2': r2_score(y_test, y_pred),
            'y_pred': y_pred
        }

        print(f"  {name}:")
        print(f"    CV RMSE: {results[name]['cv_rmse_mean']:.2f} ± {results[name]['cv_rmse_std']:.2f}")
        print(f"    Test RMSE: {results[name]['test_rmse']:.2f}")
        print(f"    Test R²: {results[name]['test_r2']:.4f}")

    return results


def plot_cv_scores(results):
    """Plot cross-validation scores."""
    names = list(results.keys())
    means = [results[name]['cv_rmse_mean'] for name in names]
    stds = [results[name]['cv_rmse_std'] for name in names]

    fig, ax = plt.subplots(figsize=(10, 6))
    x = np.arange(len(names))

    bars = ax.bar(x, means, yerr=stds, capsize=5, color=['steelblue', 'coral', 'seagreen'],
                  edgecolor='black', linewidth=1.2, alpha=0.8)

    ax.set_xlabel('Model', fontsize=14, fontweight='bold')
    ax.set_ylabel('RMSE (N)', fontsize=14, fontweight='bold')
    ax.set_title('5-Fold Cross-Validation Results', fontsize=16, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=12)
    ax.grid(axis='y', alpha=0.3)

    # Add value labels
    for i, bar in enumerate(bars):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{means[i]:.1f}\n±{stds[i]:.1f}',
                ha='center', va='bottom', fontsize=11, fontweight='bold')

    plt.tight_layout()
    save_figure(fig, 'model_cv_scores')
    plt.close()


def plot_predicted_vs_actual(y_test, y_pred, model_name='Best Model'):
    """Plot predicted vs actual values."""
    fig, ax = plt.subplots(figsize=(10, 8))

    # Scatter plot
    scatter = ax.scatter(y_test, y_pred, alpha=0.6, s=80, 
                        c=y_test, cmap='viridis', edgecolors='black', linewidth=0.5)

    # Perfect prediction line
    min_val = min(y_test.min(), y_pred.min())
    max_val = max(y_test.max(), y_pred.max())
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', lw=2, label='Perfect Prediction')

    # Statistics
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae = mean_absolute_error(y_test, y_pred)

    stats_text = f'R² = {r2:.4f}\nRMSE = {rmse:.2f} N\nMAE = {mae:.2f} N'
    ax.text(0.05, 0.95, stats_text, transform=ax.transAxes, fontsize=12,
            verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    ax.set_xlabel('Actual Resistance (N)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Predicted Resistance (N)', fontsize=14, fontweight='bold')
    ax.set_title(f'Predicted vs Actual: {model_name}', fontsize=16, fontweight='bold')
    ax.legend(fontsize=12)
    ax.grid(alpha=0.3)

    plt.colorbar(scatter, ax=ax, label='Actual Value (N)')
    plt.tight_layout()
    save_figure(fig, 'predicted_vs_actual')
    plt.close()


def plot_residuals(y_test, y_pred):
    """Plot residual histogram."""
    residuals = y_test - y_pred

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.hist(residuals, bins=30, color='steelblue', edgecolor='black', alpha=0.7)
    ax.axvline(0, color='red', linestyle='--', linewidth=2, label='Zero Error')

    # Statistics
    mean_res = residuals.mean()
    std_res = residuals.std()

    ax.set_xlabel('Residual (N)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Frequency', fontsize=14, fontweight='bold')
    ax.set_title(f'Residual Distribution (μ={mean_res:.2f}, σ={std_res:.2f})', 
                fontsize=16, fontweight='bold')
    ax.legend(fontsize=12)
    ax.grid(alpha=0.3)

    plt.tight_layout()
    save_figure(fig, 'residuals_histogram')
    plt.close()


def plot_feature_importance(model, feature_names, model_name='Random Forest'):
    """Plot feature importance."""
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
    else:
        print(f"  ⚠ {model_name} doesn't have feature_importances_")
        return

    # Sort and select top 15
    indices = np.argsort(importances)[::-1][:15]

    fig, ax = plt.subplots(figsize=(10, 8))

    y_pos = np.arange(len(indices))
    ax.barh(y_pos, importances[indices], color='teal', edgecolor='black', linewidth=1.2)
    ax.set_yticks(y_pos)
    ax.set_yticklabels([feature_names[i] for i in indices])
    ax.invert_yaxis()
    ax.set_xlabel('Importance', fontsize=14, fontweight='bold')
    ax.set_title(f'Top 15 Feature Importances: {model_name}', fontsize=16, fontweight='bold')
    ax.grid(axis='x', alpha=0.3)

    plt.tight_layout()
    save_figure(fig, 'feature_importance')
    plt.close()


def create_poster_ready_figure(y_test, y_pred, results):
    """Create a combined figure optimized for poster."""
    fig = plt.figure(figsize=(20, 12))
    gs = fig.add_gridspec(2, 3, hspace=0.3, wspace=0.3)

    # 1. Predicted vs Actual
    ax1 = fig.add_subplot(gs[0, :2])
    scatter = ax1.scatter(y_test, y_pred, alpha=0.6, s=100, 
                         c=y_test, cmap='plasma', edgecolors='black', linewidth=0.8)
    min_val = min(y_test.min(), y_pred.min())
    max_val = max(y_test.max(), y_pred.max())
    ax1.plot([min_val, max_val], [min_val, max_val], 'r--', lw=3)
    ax1.set_xlabel('Actual Resistance (N)', fontsize=18, fontweight='bold')
    ax1.set_ylabel('Predicted Resistance (N)', fontsize=18, fontweight='bold')
    ax1.set_title('Predicted vs Actual', fontsize=20, fontweight='bold')
    ax1.tick_params(labelsize=14)
    plt.colorbar(scatter, ax=ax1, label='Actual (N)')

    # 2. Residuals
    ax2 = fig.add_subplot(gs[0, 2])
    residuals = y_test - y_pred
    ax2.hist(residuals, bins=25, color='coral', edgecolor='black', alpha=0.8)
    ax2.axvline(0, color='red', linestyle='--', linewidth=2)
    ax2.set_xlabel('Residual (N)', fontsize=16, fontweight='bold')
    ax2.set_ylabel('Count', fontsize=16, fontweight='bold')
    ax2.set_title('Residuals', fontsize=18, fontweight='bold')
    ax2.tick_params(labelsize=12)

    # 3. CV Scores
    ax3 = fig.add_subplot(gs[1, :])
    names = list(results.keys())
    means = [results[name]['cv_rmse_mean'] for name in names]
    stds = [results[name]['cv_rmse_std'] for name in names]
    x = np.arange(len(names))

    bars = ax3.bar(x, means, yerr=stds, capsize=7, 
                   color=['steelblue', 'coral', 'seagreen'],
                   edgecolor='black', linewidth=1.5, alpha=0.85)
    ax3.set_xticks(x)
    ax3.set_xticklabels(names, fontsize=16)
    ax3.set_ylabel('RMSE (N)', fontsize=18, fontweight='bold')
    ax3.set_title('Model Comparison (5-Fold CV)', fontsize=20, fontweight='bold')
    ax3.tick_params(labelsize=14)
    ax3.grid(axis='y', alpha=0.4)

    for i, bar in enumerate(bars):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height,
                f'{means[i]:.1f}±{stds[i]:.1f}',
                ha='center', va='bottom', fontsize=14, fontweight='bold')

    plt.suptitle('Ship Hull Resistance Prediction - ML Model Performance', 
                fontsize=24, fontweight='bold', y=0.98)

    save_figure(fig, 'poster_ready_figure')
    plt.close()


def main(csv_path, label_col, task_type):
    """Main execution function."""
    setup_directories()

    # Load and preprocess
    df, target_col = load_dataset(csv_path, label_col)
    task = detect_task_type(df[target_col], task_type)

    if task != 'regression':
        print("⚠ This script is optimized for regression. Classification not implemented.")
        return

    # Generate EDA figures
    generate_data_stats(df)
    generate_feature_distributions(df, n_features=6)
    generate_correlation_heatmap(df)

    # Preprocess
    X_train, X_test, y_train, y_test, feature_names = preprocess_data(df, target_col)

    # Train models
    models = train_models(X_train, y_train)

    # Evaluate
    results = evaluate_models(models, X_train, y_train, X_test, y_test)

    # Generate plots
    plot_cv_scores(results)

    # Select best model
    best_model_name = min(results.keys(), key=lambda k: results[k]['test_rmse'])
    best_model = models[best_model_name]
    best_y_pred = results[best_model_name]['y_pred']

    print(f"\n🏆 Best model: {best_model_name}")

    plot_predicted_vs_actual(y_test, best_y_pred, best_model_name)
    plot_residuals(y_test, best_y_pred)
    plot_feature_importance(models['Random Forest'], feature_names, 'Random Forest')
    create_poster_ready_figure(y_test, best_y_pred, results)

    # Save best model
    model_path = f'models/{best_model_name.replace(" ", "_").lower()}_model.joblib'
    joblib.dump(best_model, model_path)
    print(f"\n💾 Model saved: {model_path}")

    # Generate QR codes
    from generate_qr import generate_qr_codes
    generate_qr_codes()

    print("\n✅ All tasks complete!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Train ML models and generate figures')
    parser.add_argument('--csv', type=str, default='data/calm_water_resistance_data_CORRECTED-1.csv',
                       help='Path to CSV file')
    parser.add_argument('--label', type=str, default='Rt_N',
                       help='Target column name')
    parser.add_argument('--task', type=str, default='regression',
                       help='Task type: regression or classification')

    args = parser.parse_args()
    main(args.csv, args.label, args.task)
