#!/bin/bash
# Upload project to GitHub
# 
# PREREQUISITES:
# 1. Install GitHub CLI: https://cli.github.com/
# 2. Login: gh auth login
#
# USAGE:
# 1. Replace REPLACE_GH_USERNAME and REPLACE_REPO_NAME below
# 2. Run: bash upload_to_github.sh

# ============ CONFIGURATION ============
GITHUB_USERNAME="REPLACE_GH_USERNAME"
REPO_NAME="REPLACE_REPO_NAME"
BRANCH="main"
# =======================================

echo "🚀 GitHub Repository Setup"
echo "=========================="

# Check if gh CLI is installed
if ! command -v gh &> /dev/null; then
    echo "❌ GitHub CLI not found. Install from: https://cli.github.com/"
    exit 1
fi

# Initialize git repository
echo "1️⃣ Initializing Git repository..."
git init
git branch -M $BRANCH

# Add files
echo "2️⃣ Adding files..."
git add .
git commit -m "Initial commit: Ship hull resistance ML project"

# Create GitHub repository using GH CLI
echo "3️⃣ Creating GitHub repository..."
gh repo create $GITHUB_USERNAME/$REPO_NAME --public --source=. --remote=origin --push

echo ""
echo "✅ Repository created and pushed!"
echo "📍 Repository URL: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo ""
echo "📸 Raw figure URLs (use these for QR codes):"
echo "https://raw.githubusercontent.com/$GITHUB_USERNAME/$REPO_NAME/$BRANCH/figures/predicted_vs_actual.png"
echo "https://raw.githubusercontent.com/$GITHUB_USERNAME/$REPO_NAME/$BRANCH/figures/poster_ready_figure.png"
echo ""
echo "⚠️  NEXT STEPS:"
echo "1. Update scripts/generate_qr.py with your GitHub username and repo name"
echo "2. Run: python scripts/generate_qr.py"
echo "3. QR codes will be in qr_codes/ directory"

# ============================================
# ALTERNATIVE METHOD: Using Git + Personal Access Token
# ============================================
# 
# If you prefer using git directly with a personal access token:
#
# 1. Create token at: https://github.com/settings/tokens
#    - Scopes needed: repo (all), workflow
#
# 2. Use token in URL:
#    git remote add origin https://$GITHUB_USERNAME:$TOKEN@github.com/$GITHUB_USERNAME/$REPO_NAME.git
#    git push -u origin $BRANCH
#
# ⚠️  WARNING: Never commit your token to the repository!
# Store it securely in environment variable or password manager.
# 
# Example with environment variable:
#    export GITHUB_TOKEN="your_token_here"
#    git remote add origin https://$GITHUB_USERNAME:$GITHUB_TOKEN@github.com/$GITHUB_USERNAME/$REPO_NAME.git
